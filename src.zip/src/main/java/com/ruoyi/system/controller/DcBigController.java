package com.ruoyi.system.controller;

import com.google.gson.Gson;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.system.domain.DcDeviceUpkeep;
import com.ruoyi.system.domain.DcOrders;
import com.ruoyi.system.domain.DcSensors;
import com.ruoyi.system.mapper.DcDeviceUpkeepMapper;
import com.ruoyi.system.service.IDcDeviceUpkeepService;
import com.ruoyi.system.service.IDcOrdersService;
import com.ruoyi.system.service.IDcSensorsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/big")
public class DcBigController extends BaseController
{
    @Autowired
    private IDcDeviceUpkeepService dcDeviceUpkeepService;
    @Autowired
    private IDcOrdersService dcOrdersService;
    @Autowired
    private RedisTemplate redisTemplate;

    /**
     * 温湿度数据列表
     */
    @RequestMapping(value = "/thlist",method = {RequestMethod.GET,RequestMethod.POST})
    public TableDataInfo thlist()
    {
        startPage();
        List rList =new ArrayList<>();
        List tlist =redisTemplate.opsForList().range("temperature_data",0,3);//温度
        List hlist =redisTemplate.opsForList().range("humidity_data",0,3);//湿度
        for (int i = 0; i < 3; i++) {
            rList.add(tlist.get(i));
            rList.add(hlist.get(i));
        }
//        for(int i=0;i<tlist.size();i++){
//            System.out.println(tlist.get(i));
//        }
        return getDataTable(rList);
    }

    /**
     * 水电压数据列表
     */
    @RequestMapping(value = "/wvlist",method = {RequestMethod.GET,RequestMethod.POST})
    public TableDataInfo wvlist()
    {
        startPage();
        List rList =new ArrayList<>();
        List wlist =redisTemplate.opsForList().range("water_pressure_data",0,3);//温度
        List vlist =redisTemplate.opsForList().range("voltage_data",0,3);//湿度
        for (int i = 0; i < 3; i++) {
//            System.out.println(wlist.get(i));
            rList.add(wlist.get(i));
            rList.add(vlist.get(i));
        }
        return getDataTable(rList);
    }

    /**
     * 设备数据：设备总数、开机总数、正常设备、故障设备、维修设备、正常率
     */
    @RequestMapping(value = "/deviceData",method = {RequestMethod.GET,RequestMethod.POST})
    public String deviceData()
    {
        String deviceDataStr =redisTemplate.opsForValue().get("device_data").toString();
        return deviceDataStr;
    }

    /**
     * 生产数据：产品总数
     */
    @RequestMapping(value = "/produceData",method = {RequestMethod.GET,RequestMethod.POST})
    public String produceData()
    {
        String produceDataStr =redisTemplate.opsForValue().get("produce_data").toString();
        return produceDataStr;
    }

    /**
     * 生产数据：设备报警总数
     */
    @RequestMapping(value = "/eqAlarmData",method = {RequestMethod.GET,RequestMethod.POST})
    public String eqAlarmData()
    {
        String eqAlarmDataStr =redisTemplate.opsForValue().get("alert_data").toString(); //设备报警key值G
        return eqAlarmDataStr;
    }

    /**
     * 生产数据：环境报警总数
     */
    @RequestMapping(value = "/envAlarmData",method = {RequestMethod.GET,RequestMethod.POST})
    public String envAlarmData()
    {
        String envAlarmDataStr =redisTemplate.opsForValue().get("env_alert_total").toString(); //环境报警key值G
        return envAlarmDataStr;
    }

    /**
     * 排产数据：产品完成总数
     */
    @RequestMapping(value = "/planData",method = {RequestMethod.GET,RequestMethod.POST})
    public String planData()
    {
        String planDataStr =redisTemplate.opsForValue().get("orders_data").toString();
        return planDataStr;
    }

    /**
     * 设备维修记录数据列表  - from mysql
     */
    @RequestMapping(value = "/deviceUpkeepList",method = {RequestMethod.GET,RequestMethod.POST})
    public TableDataInfo deviceUpkeepList()
    {
        startPage();
        DcDeviceUpkeep dcDeviceUpkeep =new DcDeviceUpkeep();
        dcDeviceUpkeep.setStatus(1L);
        List rList =dcDeviceUpkeepService.bigSelectDcDeviceUpkeepList(dcDeviceUpkeep);
        return getDataTable(rList);
    }

    /**
     * 十天产品数量
     */
    @RequestMapping(value = "/day10Produce",method = {RequestMethod.GET,RequestMethod.POST})
    public String day10Produce()
    {
        List day10ProduceList =redisTemplate.opsForList().range("day10_produce_count_data",0,10);
        Gson gson = new Gson();
        return gson.toJson(day10ProduceList);
    }

    /**
     * 产品排产数据：大屏右上角6个数据块
     */
    @RequestMapping(value = "/produceCountData",method = {RequestMethod.GET,RequestMethod.POST})
    public String produceCountData()
    {
        String produceCountDataStr =redisTemplate.opsForValue().get("produce_count_data").toString();
        return produceCountDataStr;
    }

    /**
     * 未排产订单列表  - from mysql
     */
    @RequestMapping(value = "/orderList",method = {RequestMethod.GET,RequestMethod.POST})
    public TableDataInfo orderList()
    {
        startPage();
        DcOrders order =new DcOrders();
        order.setStatus(1L);
        List rList =dcOrdersService.selectDcOrdersList(order);
        return getDataTable(rList);
    }

    /**
     * 年产品数量
     */
    @RequestMapping(value = "/yearProduce",method = {RequestMethod.GET,RequestMethod.POST})
    public String yearProduce()
    {
        List yearProduceList =redisTemplate.opsForList().range("year1_produce_count_data",0,10);
        Gson gson = new Gson();
        return gson.toJson(yearProduceList);
    }

}
