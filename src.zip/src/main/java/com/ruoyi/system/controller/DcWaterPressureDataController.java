package com.ruoyi.system.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.DcWaterPressureData;
import com.ruoyi.system.service.IDcWaterPressureDataService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 水压数据Controller
 * 
 * @author ruoyi
 * @date 2025-07-17
 */
@RestController
@RequestMapping("/system/water")
public class DcWaterPressureDataController extends BaseController
{
    @Autowired
    private IDcWaterPressureDataService dcWaterPressureDataService;

    /**
     * 查询水压数据列表
     */
    @PreAuthorize("@ss.hasPermi('system:water:list')")
    @GetMapping("/list")
    public TableDataInfo list(DcWaterPressureData dcWaterPressureData)
    {
        startPage();
        List<DcWaterPressureData> list = dcWaterPressureDataService.selectDcWaterPressureDataList(dcWaterPressureData);
        return getDataTable(list);
    }

    /**
     * 导出水压数据列表
     */
    @PreAuthorize("@ss.hasPermi('system:water:export')")
    @Log(title = "水压数据", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, DcWaterPressureData dcWaterPressureData)
    {
        List<DcWaterPressureData> list = dcWaterPressureDataService.selectDcWaterPressureDataList(dcWaterPressureData);
        ExcelUtil<DcWaterPressureData> util = new ExcelUtil<DcWaterPressureData>(DcWaterPressureData.class);
        util.exportExcel(response, list, "水压数据数据");
    }

    /**
     * 获取水压数据详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:water:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(dcWaterPressureDataService.selectDcWaterPressureDataById(id));
    }

    /**
     * 新增水压数据
     */
    @PreAuthorize("@ss.hasPermi('system:water:add')")
    @Log(title = "水压数据", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody DcWaterPressureData dcWaterPressureData)
    {
        return toAjax(dcWaterPressureDataService.insertDcWaterPressureData(dcWaterPressureData));
    }

    /**
     * 修改水压数据
     */
    @PreAuthorize("@ss.hasPermi('system:water:edit')")
    @Log(title = "水压数据", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody DcWaterPressureData dcWaterPressureData)
    {
        return toAjax(dcWaterPressureDataService.updateDcWaterPressureData(dcWaterPressureData));
    }

    /**
     * 删除水压数据
     */
    @PreAuthorize("@ss.hasPermi('system:water:remove')")
    @Log(title = "水压数据", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(dcWaterPressureDataService.deleteDcWaterPressureDataByIds(ids));
    }
}
