package com.ruoyi.system.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.ruoyi.framework.config.RedisConfig;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.DcSensors;
import com.ruoyi.system.service.IDcSensorsService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 传感器基本信息Controller
 * 
 * @author ruoyi
 * @date 2025-06-30
 */
@RestController
@RequestMapping("/system/sensors")
public class DcSensorsController extends BaseController
{
    @Autowired
    private IDcSensorsService dcSensorsService;
    @Autowired
    private RedisTemplate redisTemplate;

    /**
     * 查询传感器基本信息列表
     */
    @PreAuthorize("@ss.hasPermi('system:sensors:list')")
    @GetMapping("/list")
    public TableDataInfo list(DcSensors dcSensors)
    {
        startPage();
        List<DcSensors> list = dcSensorsService.selectDcSensorsList(dcSensors);
//        List tlist =redisTemplate.opsForList().range("temperature_data",0,2);
//        for(int i=0;i<tlist.size();i++){
//            System.out.println(tlist.get(i));
//        }
        return getDataTable(list);
    }

    /**
     * 导出传感器基本信息列表
     */
    @PreAuthorize("@ss.hasPermi('system:sensors:export')")
    @Log(title = "传感器基本信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, DcSensors dcSensors)
    {
        List<DcSensors> list = dcSensorsService.selectDcSensorsList(dcSensors);
        ExcelUtil<DcSensors> util = new ExcelUtil<DcSensors>(DcSensors.class);
        util.exportExcel(response, list, "传感器基本信息数据");
    }

    /**
     * 获取传感器基本信息详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:sensors:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(dcSensorsService.selectDcSensorsById(id));
    }

    /**
     * 新增传感器基本信息
     */
    @PreAuthorize("@ss.hasPermi('system:sensors:add')")
    @Log(title = "传感器基本信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody DcSensors dcSensors)
    {
        return toAjax(dcSensorsService.insertDcSensors(dcSensors));
    }

    /**
     * 修改传感器基本信息
     */
    @PreAuthorize("@ss.hasPermi('system:sensors:edit')")
    @Log(title = "传感器基本信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody DcSensors dcSensors)
    {
        return toAjax(dcSensorsService.updateDcSensors(dcSensors));
    }

    /**
     * 删除传感器基本信息
     */
    @PreAuthorize("@ss.hasPermi('system:sensors:remove')")
    @Log(title = "传感器基本信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(dcSensorsService.deleteDcSensorsByIds(ids));
    }
}
