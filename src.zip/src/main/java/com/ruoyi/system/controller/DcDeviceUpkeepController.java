package com.ruoyi.system.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.DcDeviceUpkeep;
import com.ruoyi.system.service.IDcDeviceUpkeepService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 设备维修记录Controller
 * 
 * @author ruoyi
 * @date 2025-07-10
 */
@RestController
@RequestMapping("/system/upkeep")
public class DcDeviceUpkeepController extends BaseController
{
    @Autowired
    private IDcDeviceUpkeepService dcDeviceUpkeepService;

    /**
     * 查询设备维修记录列表
     */
    @PreAuthorize("@ss.hasPermi('system:upkeep:list')")
    @GetMapping("/list")
    public TableDataInfo list(DcDeviceUpkeep dcDeviceUpkeep)
    {
        startPage();
        List<DcDeviceUpkeep> list = dcDeviceUpkeepService.selectDcDeviceUpkeepList(dcDeviceUpkeep);
        return getDataTable(list);
    }

    /**
     * 导出设备维修记录列表
     */
    @PreAuthorize("@ss.hasPermi('system:upkeep:export')")
    @Log(title = "设备维修记录", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, DcDeviceUpkeep dcDeviceUpkeep)
    {
        List<DcDeviceUpkeep> list = dcDeviceUpkeepService.selectDcDeviceUpkeepList(dcDeviceUpkeep);
        ExcelUtil<DcDeviceUpkeep> util = new ExcelUtil<DcDeviceUpkeep>(DcDeviceUpkeep.class);
        util.exportExcel(response, list, "设备维修记录数据");
    }

    /**
     * 获取设备维修记录详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:upkeep:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(dcDeviceUpkeepService.selectDcDeviceUpkeepById(id));
    }

    /**
     * 新增设备维修记录
     */
    @PreAuthorize("@ss.hasPermi('system:upkeep:add')")
    @Log(title = "设备维修记录", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody DcDeviceUpkeep dcDeviceUpkeep)
    {
        return toAjax(dcDeviceUpkeepService.insertDcDeviceUpkeep(dcDeviceUpkeep));
    }

    /**
     * 修改设备维修记录
     */
    @PreAuthorize("@ss.hasPermi('system:upkeep:edit')")
    @Log(title = "设备维修记录", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody DcDeviceUpkeep dcDeviceUpkeep)
    {
        return toAjax(dcDeviceUpkeepService.updateDcDeviceUpkeep(dcDeviceUpkeep));
    }

    /**
     * 删除设备维修记录
     */
    @PreAuthorize("@ss.hasPermi('system:upkeep:remove')")
    @Log(title = "设备维修记录", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(dcDeviceUpkeepService.deleteDcDeviceUpkeepByIds(ids));
    }
}
