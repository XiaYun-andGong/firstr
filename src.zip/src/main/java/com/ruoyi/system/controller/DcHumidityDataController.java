package com.ruoyi.system.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.DcHumidityData;
import com.ruoyi.system.service.IDcHumidityDataService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 湿度数据Controller
 * 
 * @author ruoyi
 * @date 2025-07-01
 */
@RestController
@RequestMapping("/system/humidity")
public class DcHumidityDataController extends BaseController
{
    @Autowired
    private IDcHumidityDataService dcHumidityDataService;

    /**
     * 查询湿度数据列表
     */
    @PreAuthorize("@ss.hasPermi('system:humidity:list')")
    @GetMapping("/list")
    public TableDataInfo list(DcHumidityData dcHumidityData)
    {
        startPage();
        List<DcHumidityData> list = dcHumidityDataService.selectDcHumidityDataList(dcHumidityData);
        return getDataTable(list);
    }

    /**
     * 导出湿度数据列表
     */
    @PreAuthorize("@ss.hasPermi('system:humidity:export')")
    @Log(title = "湿度数据", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, DcHumidityData dcHumidityData)
    {
        List<DcHumidityData> list = dcHumidityDataService.selectDcHumidityDataList(dcHumidityData);
        ExcelUtil<DcHumidityData> util = new ExcelUtil<DcHumidityData>(DcHumidityData.class);
        util.exportExcel(response, list, "湿度数据数据");
    }

    /**
     * 获取湿度数据详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:humidity:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(dcHumidityDataService.selectDcHumidityDataById(id));
    }

    /**
     * 新增湿度数据
     */
    @PreAuthorize("@ss.hasPermi('system:humidity:add')")
    @Log(title = "湿度数据", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody DcHumidityData dcHumidityData)
    {
        return toAjax(dcHumidityDataService.insertDcHumidityData(dcHumidityData));
    }

    /**
     * 修改湿度数据
     */
    @PreAuthorize("@ss.hasPermi('system:humidity:edit')")
    @Log(title = "湿度数据", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody DcHumidityData dcHumidityData)
    {
        return toAjax(dcHumidityDataService.updateDcHumidityData(dcHumidityData));
    }

    /**
     * 删除湿度数据
     */
    @PreAuthorize("@ss.hasPermi('system:humidity:remove')")
    @Log(title = "湿度数据", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(dcHumidityDataService.deleteDcHumidityDataByIds(ids));
    }
}
