package com.ruoyi.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 设备维修记录对象 dc_device_upkeep
 * 
 * @author ruoyi
 * @date 2025-07-10
 */
public class DcDeviceUpkeep extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long id;

    /** 设备外键 */
    @Excel(name = "设备外键")
    private Long dId;

    /** 设备维修状态，1-正在维修，2-结束 */
    @Excel(name = "设备维修状态，1-正在维修，2-结束")
    private Long status;

    private String dName;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }

    public void setdId(Long dId) 
    {
        this.dId = dId;
    }

    public Long getdId() 
    {
        return dId;
    }

    public void setStatus(Long status) 
    {
        this.status = status;
    }

    public Long getStatus() 
    {
        return status;
    }

    public String getdName() {
        return dName;
    }

    public void setdName(String dName) {
        this.dName = dName;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("dId", getdId())
            .append("createTime", getCreateTime())
            .append("status", getStatus())
            .append("remark", getRemark())
            .toString();
    }
}
