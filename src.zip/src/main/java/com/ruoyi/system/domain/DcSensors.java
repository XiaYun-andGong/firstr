package com.ruoyi.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 传感器基本信息对象 dc_sensors
 * 
 * @author ruoyi
 * @date 2025-06-30
 */
public class DcSensors extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键 */
    private Long id;

    /** 传感器名称 */
    @Excel(name = "传感器名称")
    private String name;

    /** 传感器类型：1-温度，2-湿度，3-电压，4-水压 */
    @Excel(name = "传感器类型：1-温度，2-湿度，3-电压，4-水压")
    private Long type;

    /** 传感器位置 */
    @Excel(name = "传感器位置")
    private String location;

    /** 备注 */
    @Excel(name = "备注")
    private String remark;

    private String isMonitor;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }

    public void setName(String name) 
    {
        this.name = name;
    }

    public String getName() 
    {
        return name;
    }

    public void setType(Long type) 
    {
        this.type = type;
    }

    public Long getType() 
    {
        return type;
    }

    public void setLocation(String location) 
    {
        this.location = location;
    }

    public String getLocation() 
    {
        return location;
    }

    public void setRemark(String remark)
    {
        this.remark = remark;
    }

    public String getRemark()
    {
        return remark;
    }

    public String getIsMonitor() {
        return isMonitor;
    }

    public void setIsMonitor(String isMonitor) {
        this.isMonitor = isMonitor;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("name", getName())
            .append("type", getType())
            .append("location", getLocation())
            .append("createTime", getCreateTime())
            .append("remark", getRemark())
            .append("isMonitor", getIsMonitor())
            .toString();
    }
}
