package com.ruoyi.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 订单基本信息对象 dc_orders
 * 
 * @author ruoyi
 * @date 2025-07-08
 */
public class DcOrders extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键 */
    private Long id;

    /** 订单编号 */
    @Excel(name = "订单编号")
    private String code;

    /** 原材料编号 */
    @Excel(name = "原材料编号")
    private String rawMaterialCode;

    /** 产品数量 */
    @Excel(name = "产品数量")
    private Long productQuantity;

    /** 订单状态，1-未排产，2-已排产，3-已完成 */
    @Excel(name = "订单状态，1-未排产，2-已排产，3-已完成")
    private Long status;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }

    public void setCode(String code) 
    {
        this.code = code;
    }

    public String getCode() 
    {
        return code;
    }

    public void setRawMaterialCode(String rawMaterialCode) 
    {
        this.rawMaterialCode = rawMaterialCode;
    }

    public String getRawMaterialCode() 
    {
        return rawMaterialCode;
    }

    public void setProductQuantity(Long productQuantity) 
    {
        this.productQuantity = productQuantity;
    }

    public Long getProductQuantity() 
    {
        return productQuantity;
    }

    public void setStatus(Long status) 
    {
        this.status = status;
    }

    public Long getStatus() 
    {
        return status;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("code", getCode())
            .append("rawMaterialCode", getRawMaterialCode())
            .append("productQuantity", getProductQuantity())
            .append("status", getStatus())
            .append("createTime", getCreateTime())
            .append("remark", getRemark())
            .toString();
    }
}
