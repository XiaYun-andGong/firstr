package com.ruoyi.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 排产或生产计划对象 dc_plan
 * 
 * @author ruoyi
 * @date 2025-07-08
 */
public class DcPlan extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long id;

    /** 订单表外键 */
    @Excel(name = "订单表外键")
    private Long oId;

    /** 排产数量 */
    @Excel(name = "排产数量")
    private Long planCount;

    /** 状态，1-未完成，2-完成 */
    @Excel(name = "状态，1-未完成，2-完成")
    private Long status;

    /** 良品数量 */
    @Excel(name = "良品数量")
    private Long passCount;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }

    public void setoId(Long oId) 
    {
        this.oId = oId;
    }

    public Long getoId() 
    {
        return oId;
    }

    public void setPlanCount(Long planCount) 
    {
        this.planCount = planCount;
    }

    public Long getPlanCount() 
    {
        return planCount;
    }

    public void setStatus(Long status) 
    {
        this.status = status;
    }

    public Long getStatus() 
    {
        return status;
    }

    public void setPassCount(Long passCount) 
    {
        this.passCount = passCount;
    }

    public Long getPassCount() 
    {
        return passCount;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("oId", getoId())
            .append("planCount", getPlanCount())
            .append("createTime", getCreateTime())
            .append("status", getStatus())
            .append("passCount", getPassCount())
            .append("remark", getRemark())
            .toString();
    }
}
