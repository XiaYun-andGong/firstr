package com.ruoyi.system.mapper;

import java.util.List;
import com.ruoyi.system.domain.DcVoltageData;

/**
 * 电压数据Mapper接口
 * 
 * @author ruoyi
 * @date 2025-07-17
 */
public interface DcVoltageDataMapper 
{
    /**
     * 查询电压数据
     * 
     * @param id 电压数据主键
     * @return 电压数据
     */
    public DcVoltageData selectDcVoltageDataById(Long id);

    /**
     * 查询电压数据列表
     * 
     * @param dcVoltageData 电压数据
     * @return 电压数据集合
     */
    public List<DcVoltageData> selectDcVoltageDataList(DcVoltageData dcVoltageData);

    /**
     * 新增电压数据
     * 
     * @param dcVoltageData 电压数据
     * @return 结果
     */
    public int insertDcVoltageData(DcVoltageData dcVoltageData);

    /**
     * 修改电压数据
     * 
     * @param dcVoltageData 电压数据
     * @return 结果
     */
    public int updateDcVoltageData(DcVoltageData dcVoltageData);

    /**
     * 删除电压数据
     * 
     * @param id 电压数据主键
     * @return 结果
     */
    public int deleteDcVoltageDataById(Long id);

    /**
     * 批量删除电压数据
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteDcVoltageDataByIds(Long[] ids);
}
