package com.ruoyi.system.mapper;

import java.util.List;
import com.ruoyi.system.domain.DcDeviceUpkeep;

/**
 * 设备维修记录Mapper接口
 * 
 * @author ruoyi
 * @date 2025-07-10
 */
public interface DcDeviceUpkeepMapper 
{
    /**
     * 查询设备维修记录
     * 
     * @param id 设备维修记录主键
     * @return 设备维修记录
     */
    public DcDeviceUpkeep selectDcDeviceUpkeepById(Long id);

    /**
     * 查询设备维修记录列表
     * 
     * @param dcDeviceUpkeep 设备维修记录
     * @return 设备维修记录集合
     */
    public List<DcDeviceUpkeep> selectDcDeviceUpkeepList(DcDeviceUpkeep dcDeviceUpkeep);

    /**
     * 新增设备维修记录
     * 
     * @param dcDeviceUpkeep 设备维修记录
     * @return 结果
     */
    public int insertDcDeviceUpkeep(DcDeviceUpkeep dcDeviceUpkeep);

    /**
     * 修改设备维修记录
     * 
     * @param dcDeviceUpkeep 设备维修记录
     * @return 结果
     */
    public int updateDcDeviceUpkeep(DcDeviceUpkeep dcDeviceUpkeep);

    /**
     * 删除设备维修记录
     * 
     * @param id 设备维修记录主键
     * @return 结果
     */
    public int deleteDcDeviceUpkeepById(Long id);

    /**
     * 批量删除设备维修记录
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteDcDeviceUpkeepByIds(Long[] ids);

    List bigSelectDcDeviceUpkeepList(DcDeviceUpkeep dcDeviceUpkeep);
}
