package com.ruoyi.system.mapper;

import java.util.List;
import com.ruoyi.system.domain.DcWaterPressureData;

/**
 * 水压数据Mapper接口
 * 
 * @author ruoyi
 * @date 2025-07-17
 */
public interface DcWaterPressureDataMapper 
{
    /**
     * 查询水压数据
     * 
     * @param id 水压数据主键
     * @return 水压数据
     */
    public DcWaterPressureData selectDcWaterPressureDataById(Long id);

    /**
     * 查询水压数据列表
     * 
     * @param dcWaterPressureData 水压数据
     * @return 水压数据集合
     */
    public List<DcWaterPressureData> selectDcWaterPressureDataList(DcWaterPressureData dcWaterPressureData);

    /**
     * 新增水压数据
     * 
     * @param dcWaterPressureData 水压数据
     * @return 结果
     */
    public int insertDcWaterPressureData(DcWaterPressureData dcWaterPressureData);

    /**
     * 修改水压数据
     * 
     * @param dcWaterPressureData 水压数据
     * @return 结果
     */
    public int updateDcWaterPressureData(DcWaterPressureData dcWaterPressureData);

    /**
     * 删除水压数据
     * 
     * @param id 水压数据主键
     * @return 结果
     */
    public int deleteDcWaterPressureDataById(Long id);

    /**
     * 批量删除水压数据
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteDcWaterPressureDataByIds(Long[] ids);
}
