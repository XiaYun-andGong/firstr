package com.ruoyi.system.mapper;

import java.util.List;
import com.ruoyi.system.domain.DcDevice;

/**
 * 设备基本信息Mapper接口
 * 
 * @author ruoyi
 * @date 2025-07-04
 */
public interface DcDeviceMapper 
{
    /**
     * 查询设备基本信息
     * 
     * @param id 设备基本信息主键
     * @return 设备基本信息
     */
    public DcDevice selectDcDeviceById(Long id);

    /**
     * 查询设备基本信息列表
     * 
     * @param dcDevice 设备基本信息
     * @return 设备基本信息集合
     */
    public List<DcDevice> selectDcDeviceList(DcDevice dcDevice);

    /**
     * 新增设备基本信息
     * 
     * @param dcDevice 设备基本信息
     * @return 结果
     */
    public int insertDcDevice(DcDevice dcDevice);

    /**
     * 修改设备基本信息
     * 
     * @param dcDevice 设备基本信息
     * @return 结果
     */
    public int updateDcDevice(DcDevice dcDevice);

    /**
     * 删除设备基本信息
     * 
     * @param id 设备基本信息主键
     * @return 结果
     */
    public int deleteDcDeviceById(Long id);

    /**
     * 批量删除设备基本信息
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteDcDeviceByIds(Long[] ids);

    int countDcDevice();
}
