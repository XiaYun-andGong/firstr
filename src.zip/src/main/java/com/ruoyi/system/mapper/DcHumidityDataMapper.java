package com.ruoyi.system.mapper;

import java.util.List;
import com.ruoyi.system.domain.DcHumidityData;

/**
 * 湿度数据Mapper接口
 * 
 * @author ruoyi
 * @date 2025-07-01
 */
public interface DcHumidityDataMapper 
{
    /**
     * 查询湿度数据
     * 
     * @param id 湿度数据主键
     * @return 湿度数据
     */
    public DcHumidityData selectDcHumidityDataById(Long id);

    /**
     * 查询湿度数据列表
     * 
     * @param dcHumidityData 湿度数据
     * @return 湿度数据集合
     */
    public List<DcHumidityData> selectDcHumidityDataList(DcHumidityData dcHumidityData);

    /**
     * 新增湿度数据
     * 
     * @param dcHumidityData 湿度数据
     * @return 结果
     */
    public int insertDcHumidityData(DcHumidityData dcHumidityData);

    /**
     * 修改湿度数据
     * 
     * @param dcHumidityData 湿度数据
     * @return 结果
     */
    public int updateDcHumidityData(DcHumidityData dcHumidityData);

    /**
     * 删除湿度数据
     * 
     * @param id 湿度数据主键
     * @return 结果
     */
    public int deleteDcHumidityDataById(Long id);

    /**
     * 批量删除湿度数据
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteDcHumidityDataByIds(Long[] ids);
}
