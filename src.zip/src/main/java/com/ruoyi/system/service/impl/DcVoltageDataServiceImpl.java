package com.ruoyi.system.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.DcVoltageDataMapper;
import com.ruoyi.system.domain.DcVoltageData;
import com.ruoyi.system.service.IDcVoltageDataService;

/**
 * 电压数据Service业务层处理
 * 
 * @author ruoyi
 * @date 2025-07-17
 */
@Service
public class DcVoltageDataServiceImpl implements IDcVoltageDataService 
{
    @Autowired
    private DcVoltageDataMapper dcVoltageDataMapper;

    /**
     * 查询电压数据
     * 
     * @param id 电压数据主键
     * @return 电压数据
     */
    @Override
    public DcVoltageData selectDcVoltageDataById(Long id)
    {
        return dcVoltageDataMapper.selectDcVoltageDataById(id);
    }

    /**
     * 查询电压数据列表
     * 
     * @param dcVoltageData 电压数据
     * @return 电压数据
     */
    @Override
    public List<DcVoltageData> selectDcVoltageDataList(DcVoltageData dcVoltageData)
    {
        return dcVoltageDataMapper.selectDcVoltageDataList(dcVoltageData);
    }

    /**
     * 新增电压数据
     * 
     * @param dcVoltageData 电压数据
     * @return 结果
     */
    @Override
    public int insertDcVoltageData(DcVoltageData dcVoltageData)
    {
        dcVoltageData.setCreateTime(DateUtils.getNowDate());
        return dcVoltageDataMapper.insertDcVoltageData(dcVoltageData);
    }

    /**
     * 修改电压数据
     * 
     * @param dcVoltageData 电压数据
     * @return 结果
     */
    @Override
    public int updateDcVoltageData(DcVoltageData dcVoltageData)
    {
        return dcVoltageDataMapper.updateDcVoltageData(dcVoltageData);
    }

    /**
     * 批量删除电压数据
     * 
     * @param ids 需要删除的电压数据主键
     * @return 结果
     */
    @Override
    public int deleteDcVoltageDataByIds(Long[] ids)
    {
        return dcVoltageDataMapper.deleteDcVoltageDataByIds(ids);
    }

    /**
     * 删除电压数据信息
     * 
     * @param id 电压数据主键
     * @return 结果
     */
    @Override
    public int deleteDcVoltageDataById(Long id)
    {
        return dcVoltageDataMapper.deleteDcVoltageDataById(id);
    }
}
