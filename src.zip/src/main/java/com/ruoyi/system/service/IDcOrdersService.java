package com.ruoyi.system.service;

import java.util.List;
import com.ruoyi.system.domain.DcOrders;

/**
 * 订单基本信息Service接口
 * 
 * @author ruoyi
 * @date 2025-07-08
 */
public interface IDcOrdersService 
{
    /**
     * 查询订单基本信息
     * 
     * @param id 订单基本信息主键
     * @return 订单基本信息
     */
    public DcOrders selectDcOrdersById(Long id);

    /**
     * 查询订单基本信息列表
     * 
     * @param dcOrders 订单基本信息
     * @return 订单基本信息集合
     */
    public List<DcOrders> selectDcOrdersList(DcOrders dcOrders);

    /**
     * 新增订单基本信息
     * 
     * @param dcOrders 订单基本信息
     * @return 结果
     */
    public int insertDcOrders(DcOrders dcOrders);

    /**
     * 修改订单基本信息
     * 
     * @param dcOrders 订单基本信息
     * @return 结果
     */
    public int updateDcOrders(DcOrders dcOrders);

    /**
     * 批量删除订单基本信息
     * 
     * @param ids 需要删除的订单基本信息主键集合
     * @return 结果
     */
    public int deleteDcOrdersByIds(Long[] ids);

    /**
     * 删除订单基本信息信息
     * 
     * @param id 订单基本信息主键
     * @return 结果
     */
    public int deleteDcOrdersById(Long id);
}
