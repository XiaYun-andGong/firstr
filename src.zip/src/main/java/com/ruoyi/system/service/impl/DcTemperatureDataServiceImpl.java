package com.ruoyi.system.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.DcTemperatureDataMapper;
import com.ruoyi.system.domain.DcTemperatureData;
import com.ruoyi.system.service.IDcTemperatureDataService;

/**
 * 温度数据Service业务层处理
 * 
 * @author ruoyi
 * @date 2025-07-17
 */
@Service
public class DcTemperatureDataServiceImpl implements IDcTemperatureDataService 
{
    @Autowired
    private DcTemperatureDataMapper dcTemperatureDataMapper;

    /**
     * 查询温度数据
     * 
     * @param id 温度数据主键
     * @return 温度数据
     */
    @Override
    public DcTemperatureData selectDcTemperatureDataById(Long id)
    {
        return dcTemperatureDataMapper.selectDcTemperatureDataById(id);
    }

    /**
     * 查询温度数据列表
     * 
     * @param dcTemperatureData 温度数据
     * @return 温度数据
     */
    @Override
    public List<DcTemperatureData> selectDcTemperatureDataList(DcTemperatureData dcTemperatureData)
    {
        return dcTemperatureDataMapper.selectDcTemperatureDataList(dcTemperatureData);
    }

    /**
     * 新增温度数据
     * 
     * @param dcTemperatureData 温度数据
     * @return 结果
     */
    @Override
    public int insertDcTemperatureData(DcTemperatureData dcTemperatureData)
    {
        dcTemperatureData.setCreateTime(DateUtils.getNowDate());
        return dcTemperatureDataMapper.insertDcTemperatureData(dcTemperatureData);
    }

    /**
     * 修改温度数据
     * 
     * @param dcTemperatureData 温度数据
     * @return 结果
     */
    @Override
    public int updateDcTemperatureData(DcTemperatureData dcTemperatureData)
    {
        return dcTemperatureDataMapper.updateDcTemperatureData(dcTemperatureData);
    }

    /**
     * 批量删除温度数据
     * 
     * @param ids 需要删除的温度数据主键
     * @return 结果
     */
    @Override
    public int deleteDcTemperatureDataByIds(Long[] ids)
    {
        return dcTemperatureDataMapper.deleteDcTemperatureDataByIds(ids);
    }

    /**
     * 删除温度数据信息
     * 
     * @param id 温度数据主键
     * @return 结果
     */
    @Override
    public int deleteDcTemperatureDataById(Long id)
    {
        return dcTemperatureDataMapper.deleteDcTemperatureDataById(id);
    }
}
