package com.ruoyi.system.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.DcWaterPressureDataMapper;
import com.ruoyi.system.domain.DcWaterPressureData;
import com.ruoyi.system.service.IDcWaterPressureDataService;

/**
 * 水压数据Service业务层处理
 * 
 * @author ruoyi
 * @date 2025-07-17
 */
@Service
public class DcWaterPressureDataServiceImpl implements IDcWaterPressureDataService 
{
    @Autowired
    private DcWaterPressureDataMapper dcWaterPressureDataMapper;

    /**
     * 查询水压数据
     * 
     * @param id 水压数据主键
     * @return 水压数据
     */
    @Override
    public DcWaterPressureData selectDcWaterPressureDataById(Long id)
    {
        return dcWaterPressureDataMapper.selectDcWaterPressureDataById(id);
    }

    /**
     * 查询水压数据列表
     * 
     * @param dcWaterPressureData 水压数据
     * @return 水压数据
     */
    @Override
    public List<DcWaterPressureData> selectDcWaterPressureDataList(DcWaterPressureData dcWaterPressureData)
    {
        return dcWaterPressureDataMapper.selectDcWaterPressureDataList(dcWaterPressureData);
    }

    /**
     * 新增水压数据
     * 
     * @param dcWaterPressureData 水压数据
     * @return 结果
     */
    @Override
    public int insertDcWaterPressureData(DcWaterPressureData dcWaterPressureData)
    {
        dcWaterPressureData.setCreateTime(DateUtils.getNowDate());
        return dcWaterPressureDataMapper.insertDcWaterPressureData(dcWaterPressureData);
    }

    /**
     * 修改水压数据
     * 
     * @param dcWaterPressureData 水压数据
     * @return 结果
     */
    @Override
    public int updateDcWaterPressureData(DcWaterPressureData dcWaterPressureData)
    {
        return dcWaterPressureDataMapper.updateDcWaterPressureData(dcWaterPressureData);
    }

    /**
     * 批量删除水压数据
     * 
     * @param ids 需要删除的水压数据主键
     * @return 结果
     */
    @Override
    public int deleteDcWaterPressureDataByIds(Long[] ids)
    {
        return dcWaterPressureDataMapper.deleteDcWaterPressureDataByIds(ids);
    }

    /**
     * 删除水压数据信息
     * 
     * @param id 水压数据主键
     * @return 结果
     */
    @Override
    public int deleteDcWaterPressureDataById(Long id)
    {
        return dcWaterPressureDataMapper.deleteDcWaterPressureDataById(id);
    }
}
