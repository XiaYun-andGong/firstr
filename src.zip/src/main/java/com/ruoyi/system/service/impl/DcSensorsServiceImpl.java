package com.ruoyi.system.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.DcSensorsMapper;
import com.ruoyi.system.domain.DcSensors;
import com.ruoyi.system.service.IDcSensorsService;

/**
 * 传感器基本信息Service业务层处理
 * 
 * @author ruoyi
 * @date 2025-06-30
 */
@Service
public class DcSensorsServiceImpl implements IDcSensorsService 
{
    @Autowired
    private DcSensorsMapper dcSensorsMapper;

    /**
     * 查询传感器基本信息
     * 
     * @param id 传感器基本信息主键
     * @return 传感器基本信息
     */
    @Override
    public DcSensors selectDcSensorsById(Long id)
    {
        return dcSensorsMapper.selectDcSensorsById(id);
    }

    /**
     * 查询传感器基本信息列表
     * 
     * @param dcSensors 传感器基本信息
     * @return 传感器基本信息
     */
    @Override
    public List<DcSensors> selectDcSensorsList(DcSensors dcSensors)
    {
        return dcSensorsMapper.selectDcSensorsList(dcSensors);
    }

    /**
     * 新增传感器基本信息
     * 
     * @param dcSensors 传感器基本信息
     * @return 结果
     */
    @Override
    public int insertDcSensors(DcSensors dcSensors)
    {
        dcSensors.setCreateTime(DateUtils.getNowDate());
        return dcSensorsMapper.insertDcSensors(dcSensors);
    }

    /**
     * 修改传感器基本信息
     * 
     * @param dcSensors 传感器基本信息
     * @return 结果
     */
    @Override
    public int updateDcSensors(DcSensors dcSensors)
    {
        return dcSensorsMapper.updateDcSensors(dcSensors);
    }

    /**
     * 批量删除传感器基本信息
     * 
     * @param ids 需要删除的传感器基本信息主键
     * @return 结果
     */
    @Override
    public int deleteDcSensorsByIds(Long[] ids)
    {
        return dcSensorsMapper.deleteDcSensorsByIds(ids);
    }

    /**
     * 删除传感器基本信息信息
     * 
     * @param id 传感器基本信息主键
     * @return 结果
     */
    @Override
    public int deleteDcSensorsById(Long id)
    {
        return dcSensorsMapper.deleteDcSensorsById(id);
    }
}
