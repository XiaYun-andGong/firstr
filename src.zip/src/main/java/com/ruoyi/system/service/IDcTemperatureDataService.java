package com.ruoyi.system.service;

import java.util.List;
import com.ruoyi.system.domain.DcTemperatureData;

/**
 * 温度数据Service接口
 * 
 * @author ruoyi
 * @date 2025-07-17
 */
public interface IDcTemperatureDataService 
{
    /**
     * 查询温度数据
     * 
     * @param id 温度数据主键
     * @return 温度数据
     */
    public DcTemperatureData selectDcTemperatureDataById(Long id);

    /**
     * 查询温度数据列表
     * 
     * @param dcTemperatureData 温度数据
     * @return 温度数据集合
     */
    public List<DcTemperatureData> selectDcTemperatureDataList(DcTemperatureData dcTemperatureData);

    /**
     * 新增温度数据
     * 
     * @param dcTemperatureData 温度数据
     * @return 结果
     */
    public int insertDcTemperatureData(DcTemperatureData dcTemperatureData);

    /**
     * 修改温度数据
     * 
     * @param dcTemperatureData 温度数据
     * @return 结果
     */
    public int updateDcTemperatureData(DcTemperatureData dcTemperatureData);

    /**
     * 批量删除温度数据
     * 
     * @param ids 需要删除的温度数据主键集合
     * @return 结果
     */
    public int deleteDcTemperatureDataByIds(Long[] ids);

    /**
     * 删除温度数据信息
     * 
     * @param id 温度数据主键
     * @return 结果
     */
    public int deleteDcTemperatureDataById(Long id);
}
