package com.ruoyi.system.service;

import java.util.List;
import com.ruoyi.system.domain.DcSensors;

/**
 * 传感器基本信息Service接口
 * 
 * @author ruoyi
 * @date 2025-06-30
 */
public interface IDcSensorsService 
{
    /**
     * 查询传感器基本信息
     * 
     * @param id 传感器基本信息主键
     * @return 传感器基本信息
     */
    public DcSensors selectDcSensorsById(Long id);

    /**
     * 查询传感器基本信息列表
     * 
     * @param dcSensors 传感器基本信息
     * @return 传感器基本信息集合
     */
    public List<DcSensors> selectDcSensorsList(DcSensors dcSensors);

    /**
     * 新增传感器基本信息
     * 
     * @param dcSensors 传感器基本信息
     * @return 结果
     */
    public int insertDcSensors(DcSensors dcSensors);

    /**
     * 修改传感器基本信息
     * 
     * @param dcSensors 传感器基本信息
     * @return 结果
     */
    public int updateDcSensors(DcSensors dcSensors);

    /**
     * 批量删除传感器基本信息
     * 
     * @param ids 需要删除的传感器基本信息主键集合
     * @return 结果
     */
    public int deleteDcSensorsByIds(Long[] ids);

    /**
     * 删除传感器基本信息信息
     * 
     * @param id 传感器基本信息主键
     * @return 结果
     */
    public int deleteDcSensorsById(Long id);
}
