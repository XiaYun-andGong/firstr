package com.ruoyi.system.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.DcOrdersMapper;
import com.ruoyi.system.domain.DcOrders;
import com.ruoyi.system.service.IDcOrdersService;

/**
 * 订单基本信息Service业务层处理
 * 
 * @author ruoyi
 * @date 2025-07-08
 */
@Service
public class DcOrdersServiceImpl implements IDcOrdersService 
{
    @Autowired
    private DcOrdersMapper dcOrdersMapper;

    /**
     * 查询订单基本信息
     * 
     * @param id 订单基本信息主键
     * @return 订单基本信息
     */
    @Override
    public DcOrders selectDcOrdersById(Long id)
    {
        return dcOrdersMapper.selectDcOrdersById(id);
    }

    /**
     * 查询订单基本信息列表
     * 
     * @param dcOrders 订单基本信息
     * @return 订单基本信息
     */
    @Override
    public List<DcOrders> selectDcOrdersList(DcOrders dcOrders)
    {
        return dcOrdersMapper.selectDcOrdersList(dcOrders);
    }

    /**
     * 新增订单基本信息
     * 
     * @param dcOrders 订单基本信息
     * @return 结果
     */
    @Override
    public int insertDcOrders(DcOrders dcOrders)
    {
        dcOrders.setCreateTime(DateUtils.getNowDate());
        return dcOrdersMapper.insertDcOrders(dcOrders);
    }

    /**
     * 修改订单基本信息
     * 
     * @param dcOrders 订单基本信息
     * @return 结果
     */
    @Override
    public int updateDcOrders(DcOrders dcOrders)
    {
        return dcOrdersMapper.updateDcOrders(dcOrders);
    }

    /**
     * 批量删除订单基本信息
     * 
     * @param ids 需要删除的订单基本信息主键
     * @return 结果
     */
    @Override
    public int deleteDcOrdersByIds(Long[] ids)
    {
        return dcOrdersMapper.deleteDcOrdersByIds(ids);
    }

    /**
     * 删除订单基本信息信息
     * 
     * @param id 订单基本信息主键
     * @return 结果
     */
    @Override
    public int deleteDcOrdersById(Long id)
    {
        return dcOrdersMapper.deleteDcOrdersById(id);
    }
}
