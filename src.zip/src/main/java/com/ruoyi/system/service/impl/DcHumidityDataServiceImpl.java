package com.ruoyi.system.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.DcHumidityDataMapper;
import com.ruoyi.system.domain.DcHumidityData;
import com.ruoyi.system.service.IDcHumidityDataService;

/**
 * 湿度数据Service业务层处理
 * 
 * @author ruoyi
 * @date 2025-07-01
 */
@Service
public class DcHumidityDataServiceImpl implements IDcHumidityDataService 
{
    @Autowired
    private DcHumidityDataMapper dcHumidityDataMapper;

    /**
     * 查询湿度数据
     * 
     * @param id 湿度数据主键
     * @return 湿度数据
     */
    @Override
    public DcHumidityData selectDcHumidityDataById(Long id)
    {
        return dcHumidityDataMapper.selectDcHumidityDataById(id);
    }

    /**
     * 查询湿度数据列表
     * 
     * @param dcHumidityData 湿度数据
     * @return 湿度数据
     */
    @Override
    public List<DcHumidityData> selectDcHumidityDataList(DcHumidityData dcHumidityData)
    {
        return dcHumidityDataMapper.selectDcHumidityDataList(dcHumidityData);
    }

    /**
     * 新增湿度数据
     * 
     * @param dcHumidityData 湿度数据
     * @return 结果
     */
    @Override
    public int insertDcHumidityData(DcHumidityData dcHumidityData)
    {
        dcHumidityData.setCreateTime(DateUtils.getNowDate());
        return dcHumidityDataMapper.insertDcHumidityData(dcHumidityData);
    }

    /**
     * 修改湿度数据
     * 
     * @param dcHumidityData 湿度数据
     * @return 结果
     */
    @Override
    public int updateDcHumidityData(DcHumidityData dcHumidityData)
    {
        return dcHumidityDataMapper.updateDcHumidityData(dcHumidityData);
    }

    /**
     * 批量删除湿度数据
     * 
     * @param ids 需要删除的湿度数据主键
     * @return 结果
     */
    @Override
    public int deleteDcHumidityDataByIds(Long[] ids)
    {
        return dcHumidityDataMapper.deleteDcHumidityDataByIds(ids);
    }

    /**
     * 删除湿度数据信息
     * 
     * @param id 湿度数据主键
     * @return 结果
     */
    @Override
    public int deleteDcHumidityDataById(Long id)
    {
        return dcHumidityDataMapper.deleteDcHumidityDataById(id);
    }
}
