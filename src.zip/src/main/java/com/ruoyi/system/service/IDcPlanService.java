package com.ruoyi.system.service;

import java.util.List;
import com.ruoyi.system.domain.DcPlan;

/**
 * 排产或生产计划Service接口
 * 
 * @author ruoyi
 * @date 2025-07-08
 */
public interface IDcPlanService 
{
    /**
     * 查询排产或生产计划
     * 
     * @param id 排产或生产计划主键
     * @return 排产或生产计划
     */
    public DcPlan selectDcPlanById(Long id);

    /**
     * 查询排产或生产计划列表
     * 
     * @param dcPlan 排产或生产计划
     * @return 排产或生产计划集合
     */
    public List<DcPlan> selectDcPlanList(DcPlan dcPlan);

    /**
     * 新增排产或生产计划
     * 
     * @param dcPlan 排产或生产计划
     * @return 结果
     */
    public int insertDcPlan(DcPlan dcPlan);

    /**
     * 修改排产或生产计划
     * 
     * @param dcPlan 排产或生产计划
     * @return 结果
     */
    public int updateDcPlan(DcPlan dcPlan);

    /**
     * 批量删除排产或生产计划
     * 
     * @param ids 需要删除的排产或生产计划主键集合
     * @return 结果
     */
    public int deleteDcPlanByIds(Long[] ids);

    /**
     * 删除排产或生产计划信息
     * 
     * @param id 排产或生产计划主键
     * @return 结果
     */
    public int deleteDcPlanById(Long id);
}
