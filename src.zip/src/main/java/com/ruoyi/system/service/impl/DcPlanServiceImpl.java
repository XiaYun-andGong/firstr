package com.ruoyi.system.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.DcPlanMapper;
import com.ruoyi.system.domain.DcPlan;
import com.ruoyi.system.service.IDcPlanService;

/**
 * 排产或生产计划Service业务层处理
 * 
 * @author ruoyi
 * @date 2025-07-08
 */
@Service
public class DcPlanServiceImpl implements IDcPlanService 
{
    @Autowired
    private DcPlanMapper dcPlanMapper;

    /**
     * 查询排产或生产计划
     * 
     * @param id 排产或生产计划主键
     * @return 排产或生产计划
     */
    @Override
    public DcPlan selectDcPlanById(Long id)
    {
        return dcPlanMapper.selectDcPlanById(id);
    }

    /**
     * 查询排产或生产计划列表
     * 
     * @param dcPlan 排产或生产计划
     * @return 排产或生产计划
     */
    @Override
    public List<DcPlan> selectDcPlanList(DcPlan dcPlan)
    {
        return dcPlanMapper.selectDcPlanList(dcPlan);
    }

    /**
     * 新增排产或生产计划
     * 
     * @param dcPlan 排产或生产计划
     * @return 结果
     */
    @Override
    public int insertDcPlan(DcPlan dcPlan)
    {
        dcPlan.setCreateTime(DateUtils.getNowDate());
        return dcPlanMapper.insertDcPlan(dcPlan);
    }

    /**
     * 修改排产或生产计划
     * 
     * @param dcPlan 排产或生产计划
     * @return 结果
     */
    @Override
    public int updateDcPlan(DcPlan dcPlan)
    {
        return dcPlanMapper.updateDcPlan(dcPlan);
    }

    /**
     * 批量删除排产或生产计划
     * 
     * @param ids 需要删除的排产或生产计划主键
     * @return 结果
     */
    @Override
    public int deleteDcPlanByIds(Long[] ids)
    {
        return dcPlanMapper.deleteDcPlanByIds(ids);
    }

    /**
     * 删除排产或生产计划信息
     * 
     * @param id 排产或生产计划主键
     * @return 结果
     */
    @Override
    public int deleteDcPlanById(Long id)
    {
        return dcPlanMapper.deleteDcPlanById(id);
    }
}
