package com.ruoyi.system.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.DcDeviceMapper;
import com.ruoyi.system.domain.DcDevice;
import com.ruoyi.system.service.IDcDeviceService;

/**
 * 设备基本信息Service业务层处理
 * 
 * @author ruoyi
 * @date 2025-07-04
 */
@Service
public class DcDeviceServiceImpl implements IDcDeviceService 
{
    @Autowired
    private DcDeviceMapper dcDeviceMapper;

    /**
     * 查询设备基本信息
     * 
     * @param id 设备基本信息主键
     * @return 设备基本信息
     */
    @Override
    public DcDevice selectDcDeviceById(Long id)
    {
        return dcDeviceMapper.selectDcDeviceById(id);
    }

    /**
     * 查询设备基本信息列表
     * 
     * @param dcDevice 设备基本信息
     * @return 设备基本信息
     */
    @Override
    public List<DcDevice> selectDcDeviceList(DcDevice dcDevice)
    {
        return dcDeviceMapper.selectDcDeviceList(dcDevice);
    }

    /**
     * 新增设备基本信息
     * 
     * @param dcDevice 设备基本信息
     * @return 结果
     */
    @Override
    public int insertDcDevice(DcDevice dcDevice)
    {
        return dcDeviceMapper.insertDcDevice(dcDevice);
    }

    /**
     * 修改设备基本信息
     * 
     * @param dcDevice 设备基本信息
     * @return 结果
     */
    @Override
    public int updateDcDevice(DcDevice dcDevice)
    {
        return dcDeviceMapper.updateDcDevice(dcDevice);
    }

    /**
     * 批量删除设备基本信息
     * 
     * @param ids 需要删除的设备基本信息主键
     * @return 结果
     */
    @Override
    public int deleteDcDeviceByIds(Long[] ids)
    {
        return dcDeviceMapper.deleteDcDeviceByIds(ids);
    }

    /**
     * 删除设备基本信息信息
     * 
     * @param id 设备基本信息主键
     * @return 结果
     */
    @Override
    public int deleteDcDeviceById(Long id)
    {
        return dcDeviceMapper.deleteDcDeviceById(id);
    }

    @Override
    public int countDcDevice() {
        return dcDeviceMapper.countDcDevice();
    }
}
