package com.ruoyi.system.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.system.domain.DcDevice;
import com.ruoyi.system.mapper.DcDeviceMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.DcDeviceUpkeepMapper;
import com.ruoyi.system.domain.DcDeviceUpkeep;
import com.ruoyi.system.service.IDcDeviceUpkeepService;

/**
 * 设备维修记录Service业务层处理
 * 
 * @author ruoyi
 * @date 2025-07-10
 */
@Service
public class DcDeviceUpkeepServiceImpl implements IDcDeviceUpkeepService 
{
    @Autowired
    private DcDeviceUpkeepMapper dcDeviceUpkeepMapper;
    @Autowired
    private DcDeviceMapper dcDeviceMapper;

    /**
     * 查询设备维修记录
     * 
     * @param id 设备维修记录主键
     * @return 设备维修记录
     */
    @Override
    public DcDeviceUpkeep selectDcDeviceUpkeepById(Long id)
    {
        return dcDeviceUpkeepMapper.selectDcDeviceUpkeepById(id);
    }

    /**
     * 查询设备维修记录列表
     * 
     * @param dcDeviceUpkeep 设备维修记录
     * @return 设备维修记录
     */
    @Override
    public List<DcDeviceUpkeep> selectDcDeviceUpkeepList(DcDeviceUpkeep dcDeviceUpkeep)
    {
        return dcDeviceUpkeepMapper.selectDcDeviceUpkeepList(dcDeviceUpkeep);
    }

    /**
     * 新增设备维修记录
     * 
     * @param dcDeviceUpkeep 设备维修记录
     * @return 结果
     */
    @Override
    public int insertDcDeviceUpkeep(DcDeviceUpkeep dcDeviceUpkeep)
    {
        dcDeviceUpkeep.setCreateTime(DateUtils.getNowDate());
        DcDevice dcDevice = dcDeviceMapper.selectDcDeviceById(dcDeviceUpkeep.getdId());
        dcDevice.setStatus(3l);
        dcDeviceMapper.updateDcDevice(dcDevice);
        return dcDeviceUpkeepMapper.insertDcDeviceUpkeep(dcDeviceUpkeep);
    }

    /**
     * 修改设备维修记录
     * 
     * @param dcDeviceUpkeep 设备维修记录
     * @return 结果
     */
    @Override
    public int updateDcDeviceUpkeep(DcDeviceUpkeep dcDeviceUpkeep)
    {
        //TODO: 设备维修状态：维修->完成，设备状态：完成->正常
        return dcDeviceUpkeepMapper.updateDcDeviceUpkeep(dcDeviceUpkeep);
    }

    /**
     * 批量删除设备维修记录
     * 
     * @param ids 需要删除的设备维修记录主键
     * @return 结果
     */
    @Override
    public int deleteDcDeviceUpkeepByIds(Long[] ids)
    {
        return dcDeviceUpkeepMapper.deleteDcDeviceUpkeepByIds(ids);
    }

    /**
     * 删除设备维修记录信息
     * 
     * @param id 设备维修记录主键
     * @return 结果
     */
    @Override
    public int deleteDcDeviceUpkeepById(Long id)
    {
        return dcDeviceUpkeepMapper.deleteDcDeviceUpkeepById(id);
    }

    @Override
    public List bigSelectDcDeviceUpkeepList(DcDeviceUpkeep dcDeviceUpkeep) {
        return dcDeviceUpkeepMapper.bigSelectDcDeviceUpkeepList(dcDeviceUpkeep);
    }
}
