package cn.edu.neu.env;

import cn.edu.neu.util0.DBUtil0;
import cn.edu.neu.util0.DateUtil0;
import cn.edu.neu.util0.NumberUtil0;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Random;

public class EnvSensorClient {
    public static void main(String[] args) throws IOException {
        Connection conn =null;
        Statement stmt =null;
        ResultSet rs =null;
        try {
            Random random = new Random();
            conn= DBUtil0.getConnection();
            stmt = conn.createStatement();
            String sql = "select * from dc_sensors where isMonitor=1";//是否模拟数据开关等于1的，再产生模拟数据
            rs = stmt.executeQuery(sql);
            DatagramSocket socket = new DatagramSocket();
            InetAddress address = InetAddress.getByName("192.168.94.103");
            int port = 20000;
            while (true) {
                //取出数据库表中所有传感器
                while (rs.next()) {
                    String packetString ="";//数据包字符串
                    double sensorValue = 0;//传感器随机值
                    int sensorId = rs.getInt("id");//从数据库表取出当前传感器的id
                    String sensorName = rs.getString("name");//从数据库表取出当前传感器的名称
                    String sensorType = rs.getString("type");//从数据库表取出当前传感器的类型
                    packetString += DateUtil0.getNowDate() + "&" + sensorName + "&" + sensorType;//组装数据包字符串
                    if("1".equals(sensorType)){//1为温度传感器
                        sensorValue=random.nextDouble()*40;
                    }else if("2".equals(sensorType)){//2为湿度传感器
                        sensorValue=random.nextDouble()*70;
                    }else if("3".equals(sensorType)){//3为电压传感器
                        sensorValue=random.nextDouble()*400;
                    }else if("4".equals(sensorType)){//4为水压传感器
                        sensorValue=random.nextDouble();
                    }
                    String sensorValueStr = NumberUtil0.getPoint2(sensorValue);//保留两位小数
                    sensorValueStr=NumberUtil0.zeroFill(sensorValueStr,6);//不够6位，右填充0
                    packetString+="&"+sensorValueStr+"&"+sensorId;//加入传感器的随机值
                    // 发送数据给服务器
                    byte[] data = packetString.getBytes();
                    DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
                    socket.send(packet);//发送UDP数据包
                    System.out.println("("+packetString+")------(发送成功)------(数据包大小:"+data.length+")");
                }
                rs.beforeFirst();//游标回到第一行之前
                Thread.sleep(30000);//休眠x秒
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if(stmt!=null){
                    stmt.close();
                }
                if(conn!=null){
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

    }
}
