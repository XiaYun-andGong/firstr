package cn.edu.neu.env;


import cn.edu.neu.util0.DBUtil0;
import org.apache.kafka.clients.producer.*;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.sql.Connection;
import java.sql.Statement;
import java.util.Properties;

public class EnvSensorServer {

    public static void main(String[] args) throws IOException{

        try {
            DatagramSocket socket = new DatagramSocket(20000); // 监听指定端口
            while(true) {
                // 接收客户端的数据
                byte[] buffer = new byte[128];
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                System.out.println("启动服务器，等待接收数据");
                socket.receive(packet); // 收取一个UDP数据包
 //               System.out.println("数据："+new String(packet.getData())+" 长度"+packet.getLength());
                String data =new String(packet.getData());//获取传感器数据
                data=data.trim();
                System.out.println("数据："+data+"长度："+data.length());
                String datas[] = data.split("&");//根据&进行数据拆分
                String sensorType = datas[2];//传感器类型
                String tableName = "";
                String topicName = "";
                if("1".equals(sensorType)){//1为温度传感器
                    tableName="dc_temperature_data";
                    topicName = "temperature_data_topic";
                }else if("2".equals(sensorType)){//2为湿度传感器
                    tableName="dc_humidity_data";
                    topicName = "humidity_data_topic";
                }else if("3".equals(sensorType)){//3为电压传感器
                    tableName="dc_voltage_data";
                    topicName = "voltage_data_topic";
                }else if("4".equals(sensorType)){//4为水压传感器
                    tableName="dc_water_pressure_data";
                    topicName = "water_pressure_data_topic";
                }
                toMysql(tableName,datas);
                toKafka(datas[0], data, topicName); // 传入日期时间字符串作为 key

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void toMysql(String tableName, String[] datas){
        Connection conn=null;
        Statement stmt =null;
        try {
            conn = DBUtil0.getConnection();
            stmt = conn.createStatement();
            String sql="insert into "+tableName+"(create_time,value,sensor_id) values(now(),'"+datas[3]+"',"+datas[4]+")";
//      System.out.println(sql);
            stmt.executeUpdate(sql);//入库
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try {
                if(stmt!=null){
                    stmt.close();
                }
                if(conn!=null){
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    public static void toKafka(String key, String data, String tName) {
        Properties props = new Properties();
        props.put("bootstrap.servers", "192.168.94.103:9092");
        props.put("acks", "0");
        props.put("retries", 0);
        props.put("batch.size", 16384);
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

        try {
            Producer<String, String> producer = new KafkaProducer<>(props);
            ProducerRecord<String, String> record = new ProducerRecord<>(tName, key, data);
            producer.send(record, new Callback() {
                public void onCompletion(RecordMetadata metadata, Exception e) {
                    if (e != null) e.printStackTrace();
                    System.out.println("message send to partition " + metadata.partition() + ", offset: " + metadata.offset());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}



