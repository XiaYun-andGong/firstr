package cn.edu.neu.util0;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil0 {
    public static final String URL = "jdbc:mysql://192.168.94.101:3306/datacenter?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=false&serverTimezone=GMT%2B8";
    public static final String USER = "root";
    public static final String PASSWORD = "123456";
    public static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    public static Connection getConnection() throws Exception
    {
        Class.forName(DRIVER);
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        return conn;
    }
}
