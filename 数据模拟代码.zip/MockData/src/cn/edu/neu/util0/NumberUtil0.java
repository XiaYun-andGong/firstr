package cn.edu.neu.util0;

import java.text.DecimalFormat;

public class NumberUtil0 {
    /**
     * 用零补齐
     * @param numStr 待补齐的数字
     * @param len 补齐的位数
     * @return
     */
    public static String zeroFill(String numStr,int len){
        String resultStr= numStr;
        if(numStr.length()<len){//需补齐
            for (int i = 0; i < len - numStr.length(); i++) {
                resultStr = resultStr+"0";
            }
        }
        return resultStr;
    }
    public static String getPoint2(double value)
    {
        DecimalFormat df = new DecimalFormat("0.00");
        return df.format(value);
    }
}
