package cn.edu.neu.device;

import cn.edu.neu.util0.DBUtil0;
import org.apache.kafka.clients.producer.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

public class DeviceDataFromMysqlToKafka {
    public static void main(String[] args) throws IOException {
        try {
            int i=0;
            while(true) {
                // 接收客户端的数据
                System.out.println("启动服务器，等待接收数据");
                String sumData=fromMysql();
                toKafka(i,sumData,"alert_data_topic");
                i++;
                Thread.sleep(5000);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String fromMysql(){
        Connection conn=null;
        Statement stmt =null;
        ResultSet rs =null;
        String r= "";
        try {
            conn = DBUtil0.getConnection();
            stmt = conn.createStatement();
            String sql="select count(*) as pq from dc_device where status=2";
//      System.out.println(sql);
            rs=stmt.executeQuery(sql);
            if(rs.next()){
                r=rs.getString("pq");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if(stmt!=null){
                    stmt.close();
                }
                if(conn!=null){
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return r;
    }

    public static void toKafka(int i, String data, String tName){
        Properties props = new Properties();
        props.put("bootstrap.servers","192.168.94.103:9092");
        props.put("acks","0");
        props.put("retries", 0);
        props.put("batch.size", 16384);
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        try {
            Producer<String, String> producer = new KafkaProducer<String, String>(props);
            ProducerRecord<String, String> record = new ProducerRecord<String, String>(tName, String.valueOf(i), data);
            producer.send(record, new Callback() {
                public void onCompletion(RecordMetadata metadata, Exception e) {
                    if (e != null)
                        e.printStackTrace();
                    System.out.println("message send to partition " + metadata.partition() + ", offset: " + metadata.offset());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

