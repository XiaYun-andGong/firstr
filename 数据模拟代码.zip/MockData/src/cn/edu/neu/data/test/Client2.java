package cn.edu.neu.data.test;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Client2 {
    public static void main(String[] args) throws IOException{
        DatagramSocket socket = new DatagramSocket();
        InetAddress address = InetAddress.getByName("192.168.94.101:3306");
        int port = 20000;
        while (true) {
            // 发送数据给服务器
            byte[] data = String.valueOf(System.currentTimeMillis()).getBytes();
            DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
            socket.send(packet);//发送UDP数据包
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }

    }
}
