package cn.edu.neu.data.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;

import javax.swing.*;

public class GroupRandomSort {
    public static void main(String[] args) {
        List<Integer> groups=new ArrayList<>();
        for(int i=1;i<=14;i++){
            groups.add(i);
        }
        Random random = new Random();
        JFrame frame = new JFrame("随机顺序");
        frame.setBounds(500, 200, 900, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        JLabel label = new JLabel("[1，2，3，4，5，6，7，8，9，10，11，12，13，14]");
        label.setBounds(50, 50, 800, 60);
        label.setFont(new java.awt.Font("宋体", 1, 30));
        JButton button = new JButton("随机顺序");
        button.setBounds(320, 150, 200, 60);
        button.setFont(new java.awt.Font("宋体", 1, 30));
        button.addActionListener(e -> {
            //随机打乱顺序
            for(int i=0;i<groups.size();i++){
                int index = random.nextInt(groups.size());
                int temp = groups.get(i);
                groups.set(i, groups.get(index));
                groups.set(index, temp);
            }
            label.setText(groups.toString());
        });
        frame.add(button);
        frame.add(label);
        frame.setVisible(true);
    }

}
