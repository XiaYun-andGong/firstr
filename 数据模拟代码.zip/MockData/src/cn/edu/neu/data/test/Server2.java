package cn.edu.neu.data.test;


import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class Server2 {
    public static void main(String[] args) throws IOException{
        int i = 0;
        DatagramSocket socket = new DatagramSocket(20000); // 监听指定端口
        while(true) {
            // 接收客户端的数据
            byte[] buffer = new byte[1024];
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
            System.out.println("启动服务器，等待接收数据");
            socket.receive(packet); // 收取一个UDP数据包
            System.out.println("客户端响应：");
            System.out.println("数据："+new String(packet.getData())+" 长度"+packet.getLength());
        }
    }
}

